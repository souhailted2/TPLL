import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import EmployeesPage from "@/pages/employees";
import AttendancePage from "@/pages/attendance";
import ReportsPage from "@/pages/reports";
import PositionsPage from "@/pages/positions";
import CompaniesPage from "@/pages/companies";
import WorkshopsPage from "@/pages/workshops";
import WorkRulesPage from "@/pages/work-rules";
import DeviceSettingsPage from "@/pages/device-settings";
import ImportDataPage from "@/pages/import-data";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/employees" component={EmployeesPage} />
      <Route path="/attendance" component={AttendancePage} />
      <Route path="/reports" component={ReportsPage} />
      <Route path="/positions" component={PositionsPage} />
      <Route path="/companies" component={CompaniesPage} />
      <Route path="/workshops" component={WorkshopsPage} />
      <Route path="/work-rules" component={WorkRulesPage} />
      <Route path="/device-settings" component={DeviceSettingsPage} />
      <Route path="/import-data" component={ImportDataPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full" dir="rtl">
            <AppSidebar />
            <div className="flex flex-col flex-1 min-w-0">
              <header className="flex items-center justify-between gap-2 p-2 border-b h-12">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <ThemeToggle />
              </header>
              <main className="flex-1 overflow-auto">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
