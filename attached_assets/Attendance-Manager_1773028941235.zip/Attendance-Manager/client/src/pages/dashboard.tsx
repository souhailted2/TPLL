import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, CalendarCheck, Clock, AlertTriangle, TrendingUp, UserCheck, FileWarning } from "lucide-react";
import type { Employee, AttendanceRecord } from "@shared/schema";

export default function Dashboard() {
  const { data: employees, isLoading: loadingEmployees } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const today = new Date().toISOString().split("T")[0];
  const { data: todayAttendance, isLoading: loadingAttendance } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance", `?date=${today}`],
  });

  const activeEmployees = employees?.filter(e => e.isActive) || [];
  const presentToday = todayAttendance?.filter(a => a.status === "present" || a.status === "late") || [];
  const lateToday = todayAttendance?.filter(a => a.status === "late") || [];
  const absentToday = activeEmployees.length - (todayAttendance?.length || 0);

  const expiringContracts = activeEmployees.filter(emp => {
    if (!emp.contractEndDate) return false;
    const diff = new Date(emp.contractEndDate).getTime() - new Date().getTime();
    return diff > 0 && diff < 30 * 24 * 60 * 60 * 1000;
  });

  const stats = [
    {
      title: "إجمالي العمال",
      value: activeEmployees.length,
      icon: Users,
      color: "text-blue-600 dark:text-blue-400",
      bg: "bg-blue-50 dark:bg-blue-950/30",
    },
    {
      title: "الحاضرون اليوم",
      value: presentToday.length,
      icon: UserCheck,
      color: "text-emerald-600 dark:text-emerald-400",
      bg: "bg-emerald-50 dark:bg-emerald-950/30",
    },
    {
      title: "المتأخرون",
      value: lateToday.length,
      icon: Clock,
      color: "text-amber-600 dark:text-amber-400",
      bg: "bg-amber-50 dark:bg-amber-950/30",
    },
    {
      title: "الغائبون",
      value: Math.max(0, absentToday),
      icon: AlertTriangle,
      color: "text-red-600 dark:text-red-400",
      bg: "bg-red-50 dark:bg-red-950/30",
    },
    {
      title: "عقود تنتهي قريباً",
      value: expiringContracts.length,
      icon: FileWarning,
      color: "text-orange-600 dark:text-orange-400",
      bg: "bg-orange-50 dark:bg-orange-950/30",
    },
  ];

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-dashboard-title">لوحة التحكم</h1>
        <p className="text-muted-foreground text-sm mt-1">نظرة عامة على حضور العمال</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((stat, i) => (
          <Card key={i}>
            <CardContent className="p-5">
              {loadingEmployees || loadingAttendance ? (
                <div className="space-y-3">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                </div>
              ) : (
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-3xl font-bold mt-1" data-testid={`text-stat-${i}`}>{stat.value}</p>
                  </div>
                  <div className={`p-2.5 rounded-md ${stat.bg}`}>
                    <stat.icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-base font-semibold">حضور اليوم</CardTitle>
            <Badge variant="secondary">{today}</Badge>
          </CardHeader>
          <CardContent>
            {loadingAttendance ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : todayAttendance && todayAttendance.length > 0 ? (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {todayAttendance.slice(0, 10).map((record) => {
                  const emp = employees?.find(e => e.id === record.employeeId);
                  return (
                    <div key={record.id} className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50" data-testid={`row-attendance-${record.id}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                          <CalendarCheck className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{emp?.name || "غير معروف"}</p>
                          <p className="text-xs text-muted-foreground">{emp?.employeeCode}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={record.status === "late" ? "destructive" : "secondary"} className="text-xs">
                          {record.status === "present" ? "حاضر" : record.status === "late" ? "متأخر" : record.status === "absent" ? "غائب" : record.status}
                        </Badge>
                        {record.checkIn && <span className="text-xs text-muted-foreground">{record.checkIn}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                <CalendarCheck className="w-10 h-10 mb-2 opacity-30" />
                <p className="text-sm">لا توجد سجلات حضور لليوم</p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-base font-semibold">إحصائيات سريعة</CardTitle>
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {loadingEmployees ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                    <span className="text-sm">نسبة الحضور اليوم</span>
                    <span className="text-sm font-bold" data-testid="text-attendance-rate">
                      {activeEmployees.length > 0
                        ? Math.round((presentToday.length / activeEmployees.length) * 100)
                        : 0}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                    <span className="text-sm">العمال النشطون</span>
                    <span className="text-sm font-bold">{activeEmployees.length}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                    <span className="text-sm">نسبة التأخير اليوم</span>
                    <span className="text-sm font-bold">
                      {presentToday.length > 0
                        ? Math.round((lateToday.length / presentToday.length) * 100)
                        : 0}%
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {expiringContracts.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-base font-semibold">عقود تنتهي قريباً</CardTitle>
                <Badge variant="destructive">{expiringContracts.length}</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {expiringContracts.map(emp => (
                    <div key={emp.id} className="flex items-center justify-between p-3 rounded-md bg-muted/50" data-testid={`row-expiring-${emp.id}`}>
                      <div>
                        <p className="text-sm font-medium">{emp.name}</p>
                        <p className="text-xs text-muted-foreground">{emp.employeeCode}</p>
                      </div>
                      <Badge variant="outline" className="text-orange-600 dark:text-orange-400 border-orange-300">
                        {emp.contractEndDate}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
