import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Pencil, Trash2, Wrench } from "lucide-react";
import type { Workshop } from "@shared/schema";

export default function WorkshopsPage() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingWorkshop, setEditingWorkshop] = useState<Workshop | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  });
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const { data: workshops, isLoading } = useQuery<Workshop[]>({ queryKey: ["/api/workshops"] });

  const createMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/workshops", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workshops"] });
      toast({ title: "تم إضافة الورشة بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { id: string } & typeof formData) => apiRequest("PATCH", `/api/workshops/${data.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workshops"] });
      toast({ title: "تم تحديث الورشة بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/workshops/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workshops"] });
      toast({ title: "تم حذف الورشة بنجاح" });
      setDeleteConfirmId(null);
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const closeDialog = () => {
    setDialogOpen(false);
    setEditingWorkshop(null);
    setFormData({ name: "", description: "" });
  };

  const openEdit = (workshop: Workshop) => {
    setEditingWorkshop(workshop);
    setFormData({
      name: workshop.name,
      description: workshop.description || "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingWorkshop) {
      updateMutation.mutate({ id: editingWorkshop.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-workshops-title">الورش</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة ورش العمل</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) closeDialog(); else setDialogOpen(true); }}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-workshop">
              <Plus className="w-4 h-4 ml-2" />
              إضافة ورشة
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editingWorkshop ? "تعديل الورشة" : "إضافة ورشة جديدة"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>الاسم</Label>
                <Input 
                  value={formData.name} 
                  onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} 
                  required 
                  data-testid="input-workshop-name" 
                />
              </div>
              <div className="space-y-2">
                <Label>الوصف</Label>
                <Input 
                  value={formData.description} 
                  onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} 
                  data-testid="input-workshop-description" 
                />
              </div>
              <Button 
                type="submit" 
                className="w-full" 
                disabled={createMutation.isPending || updateMutation.isPending} 
                data-testid="button-submit-workshop"
              >
                {(createMutation.isPending || updateMutation.isPending) ? "جاري الحفظ..." : editingWorkshop ? "تحديث" : "إضافة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : workshops && workshops.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Wrench className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا توجد ورش</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الاسم</TableHead>
                  <TableHead className="text-right">الوصف</TableHead>
                  <TableHead className="text-right">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {workshops?.map(workshop => (
                  <TableRow key={workshop.id} data-testid={`row-workshop-${workshop.id}`}>
                    <TableCell className="font-medium">{workshop.name}</TableCell>
                    <TableCell className="text-muted-foreground">{workshop.description || "-"}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => openEdit(workshop)} 
                          data-testid={`button-edit-workshop-${workshop.id}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        {deleteConfirmId === workshop.id ? (
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              variant="destructive" 
                              onClick={() => deleteMutation.mutate(workshop.id)}
                              disabled={deleteMutation.isPending}
                              data-testid={`button-confirm-delete-workshop-${workshop.id}`}
                            >
                              تأكيد
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => setDeleteConfirmId(null)}
                              data-testid={`button-cancel-delete-workshop-${workshop.id}`}
                            >
                              إلغاء
                            </Button>
                          </div>
                        ) : (
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            onClick={() => setDeleteConfirmId(workshop.id)}
                            data-testid={`button-delete-workshop-${workshop.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
