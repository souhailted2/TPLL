import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, CalendarDays, Clock, AlertCircle, DollarSign } from "lucide-react";
import type { Company, Workshop } from "@shared/schema";

interface MonthlySummary {
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  positionName: string;
  companyId: string;
  companyName: string;
  workshopId: string;
  workshopName: string;
  shift: string;
  wage: string;
  totalDays: number;
  presentDays: number;
  lateDays: number;
  absentDays: number;
  leaveDays: number;
  totalHours: number;
  totalLateMinutes: number;
  totalPenalty: number;
}

export default function ReportsPage() {
  const now = new Date();
  const [month, setMonth] = useState(String(now.getMonth() + 1).padStart(2, "0"));
  const [year, setYear] = useState(String(now.getFullYear()));
  const [filterCompany, setFilterCompany] = useState("all");
  const [filterWorkshop, setFilterWorkshop] = useState("all");

  const { data: companies } = useQuery<Company[]>({ queryKey: ["/api/companies"] });
  const { data: workshops } = useQuery<Workshop[]>({ queryKey: ["/api/workshops"] });
  const { data: report, isLoading } = useQuery<MonthlySummary[]>({
    queryKey: ["/api/reports/monthly", `?month=${month}&year=${year}`],
  });

  const filtered = report?.filter(r => {
    const matchCompany = filterCompany === "all" || r.companyId === filterCompany;
    const matchWorkshop = filterWorkshop === "all" || r.workshopId === filterWorkshop;
    return matchCompany && matchWorkshop;
  }) || [];

  const totals = filtered.reduce((acc, r) => ({
    presentDays: acc.presentDays + r.presentDays,
    lateDays: acc.lateDays + r.lateDays,
    absentDays: acc.absentDays + r.absentDays,
    leaveDays: acc.leaveDays + r.leaveDays,
    totalHours: acc.totalHours + r.totalHours,
    totalLateMinutes: acc.totalLateMinutes + r.totalLateMinutes,
    totalPenalty: acc.totalPenalty + r.totalPenalty,
  }), { presentDays: 0, lateDays: 0, absentDays: 0, leaveDays: 0, totalHours: 0, totalLateMinutes: 0, totalPenalty: 0 });

  const months = [
    { value: "01", label: "يناير" }, { value: "02", label: "فبراير" }, { value: "03", label: "مارس" },
    { value: "04", label: "أبريل" }, { value: "05", label: "مايو" }, { value: "06", label: "يونيو" },
    { value: "07", label: "يوليو" }, { value: "08", label: "أغسطس" }, { value: "09", label: "سبتمبر" },
    { value: "10", label: "أكتوبر" }, { value: "11", label: "نوفمبر" }, { value: "12", label: "ديسمبر" },
  ];

  const shiftLabel = (shift: string) => {
    if (shift === "morning") return "صباحي";
    if (shift === "evening") return "مسائي";
    return "-";
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold" data-testid="text-reports-title">التقارير الشهرية</h1>
        <p className="text-muted-foreground text-sm mt-1">ملخص الحضور والانصراف الشهري</p>
      </div>

      <div className="flex flex-wrap gap-3 items-end">
        <div className="space-y-2">
          <Label>الشهر</Label>
          <Select value={month} onValueChange={setMonth}>
            <SelectTrigger className="w-[150px]" data-testid="select-month"><SelectValue /></SelectTrigger>
            <SelectContent>
              {months.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>السنة</Label>
          <Input type="number" value={year} onChange={e => setYear(e.target.value)} className="w-[120px]" data-testid="input-year" />
        </div>
        <div className="space-y-2">
          <Label>الشركة</Label>
          <Select value={filterCompany} onValueChange={setFilterCompany}>
            <SelectTrigger className="w-[160px]" data-testid="select-report-company"><SelectValue placeholder="جميع الشركات" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الشركات</SelectItem>
              {companies?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>الورشة</Label>
          <Select value={filterWorkshop} onValueChange={setFilterWorkshop}>
            <SelectTrigger className="w-[160px]" data-testid="select-report-workshop"><SelectValue placeholder="جميع الورش" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الورش</SelectItem>
              {workshops?.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: "أيام الحضور", value: totals.presentDays, icon: CalendarDays, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
          { title: "أيام التأخير", value: totals.lateDays, icon: Clock, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30" },
          { title: "أيام الغياب", value: totals.absentDays, icon: AlertCircle, color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-950/30" },
          { title: "إجمالي الخصومات", value: totals.totalPenalty.toFixed(2), icon: DollarSign, color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-950/30" },
        ].map((stat, i) => (
          <Card key={i}>
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold mt-1" data-testid={`text-report-stat-${i}`}>{stat.value}</p>
                </div>
                <div className={`p-2.5 rounded-md ${stat.bg}`}>
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-base font-semibold">تفاصيل التقرير</CardTitle>
          <Badge variant="secondary">{months.find(m => m.value === month)?.label} {year}</Badge>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : filtered.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الرقم</TableHead>
                    <TableHead className="text-right">الاسم</TableHead>
                    <TableHead className="text-right">الشركة</TableHead>
                    <TableHead className="text-right">الورشة</TableHead>
                    <TableHead className="text-right">الفترة</TableHead>
                    <TableHead className="text-right">أيام الحضور</TableHead>
                    <TableHead className="text-right">أيام التأخير</TableHead>
                    <TableHead className="text-right">أيام الغياب</TableHead>
                    <TableHead className="text-right">الإجازات</TableHead>
                    <TableHead className="text-right">ساعات العمل</TableHead>
                    <TableHead className="text-right">دقائق التأخير</TableHead>
                    <TableHead className="text-right">الخصم</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(row => (
                    <TableRow key={row.employeeId} data-testid={`row-report-${row.employeeId}`}>
                      <TableCell className="font-mono text-sm">{row.employeeCode}</TableCell>
                      <TableCell className="font-medium">{row.employeeName}</TableCell>
                      <TableCell>{row.companyName || "-"}</TableCell>
                      <TableCell>{row.workshopName || "-"}</TableCell>
                      <TableCell>{shiftLabel(row.shift)}</TableCell>
                      <TableCell>{row.presentDays}</TableCell>
                      <TableCell>{row.lateDays > 0 ? <span className="text-amber-600 dark:text-amber-400">{row.lateDays}</span> : "0"}</TableCell>
                      <TableCell>{row.absentDays > 0 ? <span className="text-red-600 dark:text-red-400">{row.absentDays}</span> : "0"}</TableCell>
                      <TableCell>{row.leaveDays}</TableCell>
                      <TableCell>{row.totalHours.toFixed(1)}</TableCell>
                      <TableCell>{row.totalLateMinutes}</TableCell>
                      <TableCell>{row.totalPenalty > 0 ? <span className="text-red-600 dark:text-red-400 font-medium">{row.totalPenalty.toFixed(2)}</span> : "0"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableFooter>
                  <TableRow className="font-bold bg-muted/50">
                    <TableCell colSpan={5} className="text-right">الإجمالي</TableCell>
                    <TableCell>{totals.presentDays}</TableCell>
                    <TableCell>{totals.lateDays > 0 ? <span className="text-amber-600 dark:text-amber-400">{totals.lateDays}</span> : "0"}</TableCell>
                    <TableCell>{totals.absentDays > 0 ? <span className="text-red-600 dark:text-red-400">{totals.absentDays}</span> : "0"}</TableCell>
                    <TableCell>{totals.leaveDays}</TableCell>
                    <TableCell>{totals.totalHours.toFixed(1)}</TableCell>
                    <TableCell>{totals.totalLateMinutes}</TableCell>
                    <TableCell>{totals.totalPenalty > 0 ? <span className="text-red-600 dark:text-red-400 font-medium">{totals.totalPenalty.toFixed(2)}</span> : "0"}</TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <BarChart3 className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا توجد بيانات لهذا الشهر</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
