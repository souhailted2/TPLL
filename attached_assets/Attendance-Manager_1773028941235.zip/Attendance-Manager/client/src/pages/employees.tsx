import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Pencil, Search, UserCheck, UserX, Upload, FileSpreadsheet } from "lucide-react";
import type { Employee, Position, WorkRule, Company, Workshop } from "@shared/schema";

export default function EmployeesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterCompany, setFilterCompany] = useState<string>("all");
  const [filterWorkshop, setFilterWorkshop] = useState<string>("all");
  const [filterShift, setFilterShift] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: "",
    employeeCode: "",
    positionId: "",
    workRuleId: "",
    companyId: "",
    workshopId: "",
    phone: "",
    wage: "",
    shift: "",
    contractEndDate: "",
    nonRenewalDate: "",
    isActive: true,
  });

  const { data: employees, isLoading } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const { data: positions } = useQuery<Position[]>({ queryKey: ["/api/positions"] });
  const { data: workRules } = useQuery<WorkRule[]>({ queryKey: ["/api/work-rules"] });
  const { data: companies } = useQuery<Company[]>({ queryKey: ["/api/companies"] });
  const { data: workshops } = useQuery<Workshop[]>({ queryKey: ["/api/workshops"] });

  const createMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/employees", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "تم إضافة العامل بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { id: string } & typeof formData) => apiRequest("PATCH", `/api/employees/${data.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "تم تحديث العامل بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const closeDialog = () => {
    setDialogOpen(false);
    setEditingEmployee(null);
    setFormData({ name: "", employeeCode: "", positionId: "", workRuleId: "", companyId: "", workshopId: "", phone: "", wage: "", shift: "", contractEndDate: "", nonRenewalDate: "", isActive: true });
  };

  const openEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormData({
      name: emp.name,
      employeeCode: emp.employeeCode,
      positionId: emp.positionId || "",
      workRuleId: emp.workRuleId || "",
      companyId: emp.companyId || "",
      workshopId: emp.workshopId || "",
      phone: emp.phone || "",
      wage: emp.wage || "",
      shift: emp.shift || "",
      contractEndDate: emp.contractEndDate || "",
      nonRenewalDate: emp.nonRenewalDate || "",
      isActive: emp.isActive,
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const submitData = {
      ...formData,
      positionId: formData.positionId || null,
      workRuleId: formData.workRuleId || null,
      companyId: formData.companyId || null,
      workshopId: formData.workshopId || null,
      wage: formData.wage || null,
      shift: formData.shift || null,
      contractEndDate: formData.contractEndDate || null,
      nonRenewalDate: formData.nonRenewalDate || null,
    };
    if (editingEmployee) {
      updateMutation.mutate({ id: editingEmployee.id, ...submitData } as any);
    } else {
      createMutation.mutate(submitData as any);
    }
  };

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    if (lines.length < 2) {
      toast({ title: "خطأ", description: "الملف فارغ أو لا يحتوي على بيانات", variant: "destructive" });
      return;
    }

    const header = lines[0].split(/[,;\t]/).map(h => h.trim().toLowerCase());
    const codeIdx = header.findIndex(h => ["employee_code", "employeecode", "code", "رقم_العامل", "رمز_العامل", "رقم", "id", "no"].includes(h));
    const nameIdx = header.findIndex(h => ["name", "الاسم", "اسم_العامل", "اسم"].includes(h));

    if (codeIdx === -1 || nameIdx === -1) {
      toast({ title: "خطأ", description: "الملف يجب أن يحتوي على أعمدة: رقم العامل (code) والاسم (name)", variant: "destructive" });
      return;
    }

    const phoneIdx = header.findIndex(h => ["phone", "الهاتف", "هاتف", "mobile"].includes(h));
    const wageIdx = header.findIndex(h => ["wage", "الأجرة", "اجرة", "salary", "الراتب"].includes(h));
    const shiftIdx = header.findIndex(h => ["shift", "الفترة", "فترة"].includes(h));
    const contractIdx = header.findIndex(h => ["contract_end", "contract_end_date", "تاريخ_انتهاء_العقد", "انتهاء_العقد"].includes(h));

    let imported = 0;
    let skipped = 0;
    const errors: string[] = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(/[,;\t]/).map(c => c.trim());
      const code = cols[codeIdx];
      const name = cols[nameIdx];
      if (!code || !name) { skipped++; continue; }

      try {
        await apiRequest("POST", "/api/employees", {
          employeeCode: code,
          name,
          phone: phoneIdx !== -1 ? cols[phoneIdx] || null : null,
          wage: wageIdx !== -1 ? cols[wageIdx] || null : null,
          shift: shiftIdx !== -1 ? cols[shiftIdx] || null : null,
          contractEndDate: contractIdx !== -1 ? cols[contractIdx] || null : null,
          isActive: true,
        });
        imported++;
      } catch (err: any) {
        errors.push(`سطر ${i + 1}: ${err.message}`);
        skipped++;
      }
    }

    queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
    toast({
      title: `تم استيراد ${imported} عامل`,
      description: skipped > 0 ? `تم تخطي ${skipped} سجل` : undefined,
    });
    setImportDialogOpen(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const filtered = employees?.filter(emp => {
    const matchSearch = emp.name.includes(search) || emp.employeeCode.includes(search);
    const matchCompany = filterCompany === "all" || emp.companyId === filterCompany;
    const matchWorkshop = filterWorkshop === "all" || emp.workshopId === filterWorkshop;
    const matchShift = filterShift === "all" || emp.shift === filterShift;
    return matchSearch && matchCompany && matchWorkshop && matchShift;
  }) || [];

  const isContractExpiring = (date: string | null) => {
    if (!date) return false;
    const diff = new Date(date).getTime() - new Date().getTime();
    return diff > 0 && diff < 30 * 24 * 60 * 60 * 1000;
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-employees-title">العمال</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة بيانات العمال</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" data-testid="button-import-workers">
                <Upload className="w-4 h-4 ml-2" />
                استيراد من ملف
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md" dir="rtl">
              <DialogHeader>
                <DialogTitle>استيراد العمال من ملف CSV</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-md text-sm space-y-2">
                  <p className="font-medium flex items-center gap-2"><FileSpreadsheet className="w-4 h-4" /> تنسيق الملف المطلوب:</p>
                  <p>الأعمدة المطلوبة: <strong>code</strong> (رقم العامل)، <strong>name</strong> (الاسم)</p>
                  <p>أعمدة اختيارية: phone، wage، shift، contract_end_date</p>
                </div>
                <Input ref={fileInputRef} type="file" accept=".csv,.txt" onChange={handleFileImport} data-testid="input-import-file" />
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) closeDialog(); else setDialogOpen(true); }}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-employee">
                <Plus className="w-4 h-4 ml-2" />
                إضافة عامل
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
              <DialogHeader>
                <DialogTitle>{editingEmployee ? "تعديل العامل" : "إضافة عامل جديد"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>الاسم</Label>
                    <Input value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required data-testid="input-employee-name" />
                  </div>
                  <div className="space-y-2">
                    <Label>رقم العامل</Label>
                    <Input value={formData.employeeCode} onChange={e => setFormData(p => ({ ...p, employeeCode: e.target.value }))} required data-testid="input-employee-code" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>الشركة</Label>
                    <Select value={formData.companyId} onValueChange={v => setFormData(p => ({ ...p, companyId: v }))}>
                      <SelectTrigger data-testid="select-company"><SelectValue placeholder="اختر الشركة" /></SelectTrigger>
                      <SelectContent>
                        {companies?.map(c => (
                          <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>الورشة</Label>
                    <Select value={formData.workshopId} onValueChange={v => setFormData(p => ({ ...p, workshopId: v }))}>
                      <SelectTrigger data-testid="select-workshop"><SelectValue placeholder="اختر الورشة" /></SelectTrigger>
                      <SelectContent>
                        {workshops?.map(w => (
                          <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>الأجرة</Label>
                    <Input type="number" step="0.01" value={formData.wage} onChange={e => setFormData(p => ({ ...p, wage: e.target.value }))} data-testid="input-wage" />
                  </div>
                  <div className="space-y-2">
                    <Label>الفترة</Label>
                    <Select value={formData.shift} onValueChange={v => setFormData(p => ({ ...p, shift: v }))}>
                      <SelectTrigger data-testid="select-shift"><SelectValue placeholder="اختر الفترة" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">صباحي</SelectItem>
                        <SelectItem value="evening">مسائي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>تاريخ انتهاء العقد</Label>
                    <Input type="date" value={formData.contractEndDate} onChange={e => setFormData(p => ({ ...p, contractEndDate: e.target.value }))} data-testid="input-contract-end" />
                  </div>
                  <div className="space-y-2">
                    <Label>تاريخ عدم التجديد</Label>
                    <Input type="date" value={formData.nonRenewalDate} onChange={e => setFormData(p => ({ ...p, nonRenewalDate: e.target.value }))} data-testid="input-non-renewal" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>المنصب</Label>
                    <Select value={formData.positionId} onValueChange={v => setFormData(p => ({ ...p, positionId: v }))}>
                      <SelectTrigger data-testid="select-position"><SelectValue placeholder="اختر المنصب" /></SelectTrigger>
                      <SelectContent>
                        {positions?.map(pos => (
                          <SelectItem key={pos.id} value={pos.id}>{pos.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>قانون العمل</Label>
                    <Select value={formData.workRuleId} onValueChange={v => setFormData(p => ({ ...p, workRuleId: v }))}>
                      <SelectTrigger data-testid="select-work-rule"><SelectValue placeholder="اختر قانون العمل" /></SelectTrigger>
                      <SelectContent>
                        {workRules?.map(rule => (
                          <SelectItem key={rule.id} value={rule.id}>{rule.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>الهاتف</Label>
                  <Input value={formData.phone || ""} onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))} data-testid="input-employee-phone" />
                </div>
                <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-submit-employee">
                  {(createMutation.isPending || updateMutation.isPending) ? "جاري الحفظ..." : editingEmployee ? "تحديث" : "إضافة"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="بحث بالاسم أو الرقم..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" data-testid="input-search-employee" />
        </div>
        <Select value={filterCompany} onValueChange={setFilterCompany}>
          <SelectTrigger className="w-[160px]" data-testid="select-filter-company"><SelectValue placeholder="جميع الشركات" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الشركات</SelectItem>
            {companies?.map(c => (
              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterWorkshop} onValueChange={setFilterWorkshop}>
          <SelectTrigger className="w-[160px]" data-testid="select-filter-workshop"><SelectValue placeholder="جميع الورش" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الورش</SelectItem>
            {workshops?.map(w => (
              <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterShift} onValueChange={setFilterShift}>
          <SelectTrigger className="w-[130px]" data-testid="select-filter-shift"><SelectValue placeholder="جميع الفترات" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الفترات</SelectItem>
            <SelectItem value="morning">صباحي</SelectItem>
            <SelectItem value="evening">مسائي</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <UserX className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا يوجد عمال</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الرقم</TableHead>
                    <TableHead className="text-right">الاسم</TableHead>
                    <TableHead className="text-right">الشركة</TableHead>
                    <TableHead className="text-right">الورشة</TableHead>
                    <TableHead className="text-right">الفترة</TableHead>
                    <TableHead className="text-right">الأجرة</TableHead>
                    <TableHead className="text-right">انتهاء العقد</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(emp => (
                    <TableRow key={emp.id} data-testid={`row-employee-${emp.id}`}>
                      <TableCell className="font-mono text-sm">{emp.employeeCode}</TableCell>
                      <TableCell className="font-medium">{emp.name}</TableCell>
                      <TableCell>
                        {emp.companyId ? (
                          <Badge variant="secondary">{companies?.find(c => c.id === emp.companyId)?.name || "-"}</Badge>
                        ) : "-"}
                      </TableCell>
                      <TableCell>
                        {emp.workshopId ? (
                          <Badge variant="outline">{workshops?.find(w => w.id === emp.workshopId)?.name || "-"}</Badge>
                        ) : "-"}
                      </TableCell>
                      <TableCell>
                        {emp.shift === "morning" ? <Badge variant="secondary">صباحي</Badge> :
                         emp.shift === "evening" ? <Badge variant="secondary">مسائي</Badge> : "-"}
                      </TableCell>
                      <TableCell>{emp.wage ? `${emp.wage}` : "-"}</TableCell>
                      <TableCell>
                        {emp.contractEndDate ? (
                          <span className={isContractExpiring(emp.contractEndDate) ? "text-red-600 dark:text-red-400 font-medium" : ""}>
                            {emp.contractEndDate}
                          </span>
                        ) : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={emp.isActive ? "default" : "destructive"}>
                          {emp.isActive ? (
                            <span className="flex items-center gap-1"><UserCheck className="w-3 h-3" /> نشط</span>
                          ) : "غير نشط"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button size="icon" variant="ghost" onClick={() => openEdit(emp)} data-testid={`button-edit-employee-${emp.id}`}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
