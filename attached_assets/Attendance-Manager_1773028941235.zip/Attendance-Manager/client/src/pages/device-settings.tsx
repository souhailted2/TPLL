import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Plus, Pencil, Trash2, Wifi, WifiOff, MonitorSmartphone, Info, RefreshCw, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import type { DeviceSettings } from "@shared/schema";

export default function DeviceSettingsPage() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<DeviceSettings | null>(null);
  const [syncResult, setSyncResult] = useState<{
    imported: number;
    skipped: number;
    duplicates: number;
    total: number;
    errors: string[];
    message: string;
  } | null>(null);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    info?: { userCounts: number; logCounts: number; logCapacity: number };
  } | null>(null);
  const [activeTestId, setActiveTestId] = useState<string | null>(null);
  const [activeSyncId, setActiveSyncId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    ipAddress: "",
    port: "4370",
    username: "",
    password: "",
  });

  const { data: devices, isLoading } = useQuery<DeviceSettings[]>({ queryKey: ["/api/device-settings"] });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/device-settings", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/device-settings"] });
      toast({ title: "تم إضافة الجهاز بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { id: string } & any) => apiRequest("PATCH", `/api/device-settings/${data.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/device-settings"] });
      toast({ title: "تم تحديث الجهاز بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/device-settings/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/device-settings"] });
      toast({ title: "تم حذف الجهاز" });
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const testMutation = useMutation({
    mutationFn: async (id: string) => {
      setActiveTestId(id);
      const res = await apiRequest("POST", `/api/device-settings/${id}/test`);
      return res.json();
    },
    onSuccess: (data) => {
      setTestResult(data);
      if (data.success) {
        toast({ title: "تم الاتصال بنجاح", description: data.message });
      } else {
        toast({ title: "فشل الاتصال", description: data.message, variant: "destructive" });
      }
    },
    onError: (err: Error) => {
      setTestResult({ success: false, message: err.message });
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    },
    onSettled: () => setActiveTestId(null),
  });

  const syncMutation = useMutation({
    mutationFn: async (id: string) => {
      setActiveSyncId(id);
      const res = await apiRequest("POST", `/api/device-settings/${id}/sync`);
      return res.json();
    },
    onSuccess: (data) => {
      setSyncResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({
        title: "تمت المزامنة",
        description: data.message || `تم استيراد ${data.imported} سجل`,
      });
    },
    onError: (err: Error) => {
      toast({ title: "خطأ في المزامنة", description: err.message, variant: "destructive" });
    },
    onSettled: () => setActiveSyncId(null),
  });

  const closeDialog = () => {
    setDialogOpen(false);
    setEditing(null);
    setFormData({ name: "", ipAddress: "", port: "4370", username: "", password: "" });
  };

  const openEdit = (device: DeviceSettings) => {
    setEditing(device);
    setFormData({
      name: device.name,
      ipAddress: device.ipAddress,
      port: String(device.port),
      username: device.username || "",
      password: device.password || "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...formData, port: parseInt(formData.port) || 4370 };
    if (editing) {
      updateMutation.mutate({ id: editing.id, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-device-settings-title">إعدادات أجهزة الحضور</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة أجهزة الحضور والانصراف ومزامنة البيانات</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) closeDialog(); else setDialogOpen(true); }}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-device">
              <Plus className="w-4 h-4 ml-2" />
              إضافة جهاز
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editing ? "تعديل الجهاز" : "إضافة جهاز جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>اسم الجهاز</Label>
                <Input value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} placeholder="مثال: جهاز البصمة الرئيسي" required data-testid="input-device-name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>عنوان IP</Label>
                  <Input value={formData.ipAddress} onChange={e => setFormData(p => ({ ...p, ipAddress: e.target.value }))} placeholder="192.168.1.251" required data-testid="input-device-ip" />
                </div>
                <div className="space-y-2">
                  <Label>المنفذ (Port)</Label>
                  <Input type="number" value={formData.port} onChange={e => setFormData(p => ({ ...p, port: e.target.value }))} placeholder="4370" data-testid="input-device-port" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>اسم المستخدم</Label>
                  <Input value={formData.username} onChange={e => setFormData(p => ({ ...p, username: e.target.value }))} placeholder="368" data-testid="input-device-username" />
                </div>
                <div className="space-y-2">
                  <Label>كلمة المرور</Label>
                  <Input type="password" value={formData.password} onChange={e => setFormData(p => ({ ...p, password: e.target.value }))} placeholder="123" data-testid="input-device-password" />
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-submit-device">
                {(createMutation.isPending || updateMutation.isPending) ? "جاري الحفظ..." : editing ? "تحديث" : "إضافة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Alert>
        <Info className="w-4 h-4" />
        <AlertDescription>
          يمكنك اختبار الاتصال بالجهاز ومزامنة بيانات الحضور تلقائياً. يجب أن يكون التطبيق يعمل على جهاز متصل بنفس الشبكة المحلية لآلة الحضور.
          النظام يسحب البصمات من الجهاز ويطابقها مع أرقام الموظفين المسجلين في النظام.
        </AlertDescription>
      </Alert>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : devices && devices.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الجهاز</TableHead>
                  <TableHead className="text-right">عنوان IP</TableHead>
                  <TableHead className="text-right">المنفذ</TableHead>
                  <TableHead className="text-right">اسم المستخدم</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {devices.map(device => (
                  <TableRow key={device.id} data-testid={`row-device-${device.id}`}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                          <MonitorSmartphone className="w-4 h-4 text-primary" />
                        </div>
                        <span className="font-medium">{device.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{device.ipAddress}</TableCell>
                    <TableCell>{device.port}</TableCell>
                    <TableCell>{device.username || "-"}</TableCell>
                    <TableCell>
                      <Badge variant={device.isActive ? "default" : "secondary"}>
                        {device.isActive ? "مفعّل" : "معطّل"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { setTestResult(null); testMutation.mutate(device.id); }}
                          disabled={activeTestId === device.id}
                          data-testid={`button-test-device-${device.id}`}
                        >
                          {activeTestId === device.id ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Wifi className="w-4 h-4 ml-1" />}
                          اختبار
                        </Button>
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => { setSyncResult(null); syncMutation.mutate(device.id); }}
                          disabled={activeSyncId === device.id}
                          data-testid={`button-sync-device-${device.id}`}
                        >
                          {activeSyncId === device.id ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <RefreshCw className="w-4 h-4 ml-1" />}
                          مزامنة
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => openEdit(device)} data-testid={`button-edit-device-${device.id}`}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(device.id)} data-testid={`button-delete-device-${device.id}`}>
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <WifiOff className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا توجد أجهزة مضافة</p>
              <p className="text-xs mt-1">اضغط على "إضافة جهاز" لإضافة جهاز حضور جديد</p>
            </div>
          )}
        </CardContent>
      </Card>

      {testResult && (
        <Card data-testid="card-test-result">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {testResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <AlertCircle className="w-5 h-5 text-destructive" />
              )}
              نتيجة اختبار الاتصال
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={testResult.success ? "text-emerald-600 dark:text-emerald-400" : "text-destructive"}>
              {testResult.message}
            </p>
            {testResult.info && (
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-primary">{testResult.info.userCounts}</p>
                  <p className="text-xs text-muted-foreground">عدد المستخدمين</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-primary">{testResult.info.logCounts}</p>
                  <p className="text-xs text-muted-foreground">عدد السجلات</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-primary">{testResult.info.logCapacity}</p>
                  <p className="text-xs text-muted-foreground">سعة السجلات</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {syncResult && (
        <Card data-testid="card-sync-result">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {syncResult.imported > 0 ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <AlertCircle className="w-5 h-5 text-amber-500" />
              )}
              نتيجة المزامنة
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">{syncResult.message}</p>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <p className="text-2xl font-bold text-primary" data-testid="text-sync-total">{syncResult.total}</p>
                <p className="text-xs text-muted-foreground">إجمالي البصمات</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
                <p className="text-2xl font-bold text-emerald-600" data-testid="text-sync-imported">{syncResult.imported}</p>
                <p className="text-xs text-muted-foreground">تم الاستيراد</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30">
                <p className="text-2xl font-bold text-blue-600" data-testid="text-sync-duplicates">{syncResult.duplicates}</p>
                <p className="text-xs text-muted-foreground">مكررات</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30">
                <p className="text-2xl font-bold text-amber-600" data-testid="text-sync-skipped">{syncResult.skipped}</p>
                <p className="text-xs text-muted-foreground">تم تخطيها</p>
              </div>
            </div>

            {syncResult.errors.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-destructive">الأخطاء:</p>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {syncResult.errors.map((err, i) => (
                    <p key={i} className="text-xs text-destructive bg-destructive/5 p-2 rounded">
                      {err}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
