import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload, FileText, CheckCircle2, AlertCircle, Info, Download } from "lucide-react";

export default function ImportDataPage() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importResult, setImportResult] = useState<{
    imported: number;
    skipped: number;
    total: number;
    errors: string[];
  } | null>(null);

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/import/attendance", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "فشل الاستيراد");
      }
      return res.json();
    },
    onSuccess: (data) => {
      setImportResult(data);
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({
        title: "تم الاستيراد",
        description: `تم استيراد ${data.imported} سجل من أصل ${data.total}`,
      });
    },
    onError: (err: Error) => {
      toast({ title: "خطأ في الاستيراد", description: err.message, variant: "destructive" });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setImportResult(null);
    }
  };

  const handleImport = () => {
    if (selectedFile) {
      importMutation.mutate(selectedFile);
    }
  };

  const downloadSample = () => {
    const csvContent = "employee_code,date,check_in,check_out\nEMP001,2025-02-23,08:00,16:00\nEMP002,2025-02-23,08:15,16:30\nEMP003,2025-02-23,09:00,15:00\n";
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "attendance_sample.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-import-title">استيراد بيانات الحضور</h1>
          <p className="text-muted-foreground text-sm mt-1">استيراد سجلات الحضور من ملفات CSV المصدّرة من آلة الحضور</p>
        </div>
      </div>

      <Alert>
        <Info className="w-4 h-4" />
        <AlertDescription>
          <p className="font-medium mb-2">تنسيق الملف المطلوب:</p>
          <p>يجب أن يكون الملف بصيغة CSV ويحتوي على الأعمدة التالية:</p>
          <ul className="list-disc list-inside mt-1 space-y-1 text-sm">
            <li><strong>رقم الموظف</strong> (employee_code أو code أو No أو ID)</li>
            <li><strong>التاريخ</strong> (date أو التاريخ) بصيغة YYYY-MM-DD</li>
            <li><strong>وقت الحضور</strong> (check_in أو checkin أو time_in أو in) بصيغة HH:MM</li>
            <li><strong>وقت الانصراف</strong> (check_out أو checkout أو time_out أو out) بصيغة HH:MM</li>
          </ul>
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              رفع الملف
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
              data-testid="dropzone-upload"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt"
                onChange={handleFileSelect}
                className="hidden"
                data-testid="input-file-upload"
              />
              {selectedFile ? (
                <div className="space-y-2">
                  <FileText className="w-10 h-10 mx-auto text-primary" />
                  <p className="font-medium">{selectedFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(1)} كيلوبايت
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="w-10 h-10 mx-auto text-muted-foreground/50" />
                  <p className="text-sm text-muted-foreground">اضغط هنا لاختيار ملف CSV</p>
                  <p className="text-xs text-muted-foreground">أو اسحب الملف وأفلته هنا</p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleImport}
                disabled={!selectedFile || importMutation.isPending}
                className="flex-1"
                data-testid="button-import"
              >
                {importMutation.isPending ? "جاري الاستيراد..." : "استيراد البيانات"}
              </Button>
              <Button variant="outline" onClick={downloadSample} data-testid="button-download-sample">
                <Download className="w-4 h-4 ml-2" />
                تحميل نموذج
              </Button>
            </div>
          </CardContent>
        </Card>

        {importResult && (
          <Card data-testid="card-import-result">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {importResult.imported > 0 ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                )}
                نتيجة الاستيراد
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-primary" data-testid="text-total-records">{importResult.total}</p>
                  <p className="text-xs text-muted-foreground">إجمالي السجلات</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
                  <p className="text-2xl font-bold text-emerald-600" data-testid="text-imported-count">{importResult.imported}</p>
                  <p className="text-xs text-muted-foreground">تم الاستيراد</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30">
                  <p className="text-2xl font-bold text-amber-600" data-testid="text-skipped-count">{importResult.skipped}</p>
                  <p className="text-xs text-muted-foreground">تم تخطيها</p>
                </div>
              </div>

              {importResult.errors.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-destructive">الأخطاء:</p>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {importResult.errors.map((err, i) => (
                      <p key={i} className="text-xs text-destructive bg-destructive/5 p-2 rounded">
                        {err}
                      </p>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            مثال على تنسيق الملف
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right font-mono text-xs">employee_code</TableHead>
                <TableHead className="text-right font-mono text-xs">date</TableHead>
                <TableHead className="text-right font-mono text-xs">check_in</TableHead>
                <TableHead className="text-right font-mono text-xs">check_out</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-mono text-sm">EMP001</TableCell>
                <TableCell className="font-mono text-sm">2025-02-23</TableCell>
                <TableCell className="font-mono text-sm">08:00</TableCell>
                <TableCell className="font-mono text-sm">16:00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono text-sm">EMP002</TableCell>
                <TableCell className="font-mono text-sm">2025-02-23</TableCell>
                <TableCell className="font-mono text-sm">08:15</TableCell>
                <TableCell className="font-mono text-sm">16:30</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono text-sm">EMP003</TableCell>
                <TableCell className="font-mono text-sm">2025-02-23</TableCell>
                <TableCell className="font-mono text-sm">09:00</TableCell>
                <TableCell className="font-mono text-sm">15:00</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
