import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Scale, Trash2 } from "lucide-react";
import type { WorkRule } from "@shared/schema";

export default function WorkRulesPage() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<WorkRule | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    workStartTime: "08:00",
    workEndTime: "17:00",
    lateGraceMinutes: 0,
    latePenaltyPerMinute: "0",
    earlyLeavePenaltyPerMinute: "0",
    absencePenalty: "0",
    isDefault: false,
  });

  const { data: workRules, isLoading } = useQuery<WorkRule[]>({ queryKey: ["/api/work-rules"] });

  const createMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/work-rules", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work-rules"] });
      toast({ title: "تم إضافة قانون العمل بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { id: string } & typeof formData) => apiRequest("PATCH", `/api/work-rules/${data.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work-rules"] });
      toast({ title: "تم تحديث قانون العمل بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/work-rules/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work-rules"] });
      toast({ title: "تم حذف القانون" });
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const closeDialog = () => {
    setDialogOpen(false);
    setEditing(null);
    setFormData({
      name: "",
      workStartTime: "08:00",
      workEndTime: "17:00",
      lateGraceMinutes: 0,
      latePenaltyPerMinute: "0",
      earlyLeavePenaltyPerMinute: "0",
      absencePenalty: "0",
      isDefault: false,
    });
  };

  const openEdit = (rule: WorkRule) => {
    setEditing(rule);
    setFormData({
      name: rule.name,
      workStartTime: rule.workStartTime,
      workEndTime: rule.workEndTime,
      lateGraceMinutes: rule.lateGraceMinutes,
      latePenaltyPerMinute: rule.latePenaltyPerMinute,
      earlyLeavePenaltyPerMinute: rule.earlyLeavePenaltyPerMinute,
      absencePenalty: rule.absencePenalty,
      isDefault: rule.isDefault,
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editing) {
      updateMutation.mutate({ id: editing.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-rules-title">قوانين العمل</h1>
          <p className="text-muted-foreground text-sm mt-1">إعداد أوقات العمل والخصومات</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) closeDialog(); else setDialogOpen(true); }}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-rule">
              <Plus className="w-4 h-4 ml-2" />
              إضافة قانون
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editing ? "تعديل القانون" : "إضافة قانون عمل جديد"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>اسم القانون</Label>
                <Input value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} required data-testid="input-rule-name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>وقت بدء العمل</Label>
                  <Input type="time" value={formData.workStartTime} onChange={e => setFormData(p => ({ ...p, workStartTime: e.target.value }))} required data-testid="input-start-time" />
                </div>
                <div className="space-y-2">
                  <Label>وقت نهاية العمل</Label>
                  <Input type="time" value={formData.workEndTime} onChange={e => setFormData(p => ({ ...p, workEndTime: e.target.value }))} required data-testid="input-end-time" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>فترة السماح بالتأخير (دقيقة)</Label>
                <Input type="number" min="0" value={formData.lateGraceMinutes} onChange={e => setFormData(p => ({ ...p, lateGraceMinutes: parseInt(e.target.value) || 0 }))} data-testid="input-grace-minutes" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>خصم التأخير لكل دقيقة</Label>
                  <Input type="number" step="0.01" min="0" value={formData.latePenaltyPerMinute} onChange={e => setFormData(p => ({ ...p, latePenaltyPerMinute: e.target.value }))} data-testid="input-late-penalty" />
                </div>
                <div className="space-y-2">
                  <Label>خصم الخروج المبكر لكل دقيقة</Label>
                  <Input type="number" step="0.01" min="0" value={formData.earlyLeavePenaltyPerMinute} onChange={e => setFormData(p => ({ ...p, earlyLeavePenaltyPerMinute: e.target.value }))} data-testid="input-early-penalty" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>خصم الغياب</Label>
                <Input type="number" step="0.01" min="0" value={formData.absencePenalty} onChange={e => setFormData(p => ({ ...p, absencePenalty: e.target.value }))} data-testid="input-absence-penalty" />
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={formData.isDefault} onCheckedChange={v => setFormData(p => ({ ...p, isDefault: v }))} data-testid="switch-default-rule" />
                <Label>قانون افتراضي</Label>
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-submit-rule">
                {(createMutation.isPending || updateMutation.isPending) ? "جاري الحفظ..." : editing ? "تحديث" : "إضافة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : workRules && workRules.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">القانون</TableHead>
                    <TableHead className="text-right">وقت البدء</TableHead>
                    <TableHead className="text-right">وقت النهاية</TableHead>
                    <TableHead className="text-right">فترة السماح</TableHead>
                    <TableHead className="text-right">خصم التأخير/دقيقة</TableHead>
                    <TableHead className="text-right">خصم الغياب</TableHead>
                    <TableHead className="text-right">افتراضي</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {workRules.map(rule => (
                    <TableRow key={rule.id} data-testid={`row-rule-${rule.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                            <Scale className="w-4 h-4 text-primary" />
                          </div>
                          <span className="font-medium">{rule.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{rule.workStartTime}</TableCell>
                      <TableCell>{rule.workEndTime}</TableCell>
                      <TableCell>{rule.lateGraceMinutes} دقيقة</TableCell>
                      <TableCell>{rule.latePenaltyPerMinute}</TableCell>
                      <TableCell>{rule.absencePenalty}</TableCell>
                      <TableCell>
                        {rule.isDefault ? <Badge>افتراضي</Badge> : <Badge variant="secondary">لا</Badge>}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(rule)} data-testid={`button-edit-rule-${rule.id}`}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(rule.id)} data-testid={`button-delete-rule-${rule.id}`}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Scale className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا توجد قوانين عمل مضافة</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
