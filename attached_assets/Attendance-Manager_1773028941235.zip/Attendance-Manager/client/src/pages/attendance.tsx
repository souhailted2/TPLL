import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Pencil, CalendarCheck, Clock } from "lucide-react";
import type { Employee, AttendanceRecord, Company, Workshop } from "@shared/schema";

export default function AttendancePage() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);
  const [formData, setFormData] = useState({
    employeeId: "",
    date: selectedDate,
    checkIn: "",
    checkOut: "",
    status: "present",
    notes: "",
  });

  const { data: employees } = useQuery<Employee[]>({ queryKey: ["/api/employees"] });
  const { data: companies } = useQuery<Company[]>({ queryKey: ["/api/companies"] });
  const { data: workshops } = useQuery<Workshop[]>({ queryKey: ["/api/workshops"] });
  const { data: attendance, isLoading } = useQuery<AttendanceRecord[]>({
    queryKey: ["/api/attendance", `?date=${selectedDate}`],
  });

  const createMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("POST", "/api/attendance", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({ title: "تم تسجيل الحضور بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: (data: { id: string } & typeof formData) => apiRequest("PATCH", `/api/attendance/${data.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({ title: "تم تحديث السجل بنجاح" });
      closeDialog();
    },
    onError: (err: Error) => toast({ title: "خطأ", description: err.message, variant: "destructive" }),
  });

  const closeDialog = () => {
    setDialogOpen(false);
    setEditingRecord(null);
    setFormData({ employeeId: "", date: selectedDate, checkIn: "", checkOut: "", status: "present", notes: "" });
  };

  const openEdit = (record: AttendanceRecord) => {
    setEditingRecord(record);
    setFormData({
      employeeId: record.employeeId,
      date: record.date,
      checkIn: record.checkIn || "",
      checkOut: record.checkOut || "",
      status: record.status,
      notes: record.notes || "",
    });
    setDialogOpen(true);
  };

  const openAdd = () => {
    setFormData({ ...formData, date: selectedDate });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRecord) {
      updateMutation.mutate({ id: editingRecord.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const statusLabel = (status: string) => {
    switch (status) {
      case "present": return "حاضر";
      case "late": return "متأخر";
      case "absent": return "غائب";
      case "leave": return "إجازة";
      default: return status;
    }
  };

  const statusVariant = (status: string) => {
    switch (status) {
      case "present": return "default" as const;
      case "late": return "secondary" as const;
      case "absent": return "destructive" as const;
      default: return "secondary" as const;
    }
  };

  const shiftLabel = (shift: string | null) => {
    if (shift === "morning") return "صباحي";
    if (shift === "evening") return "مسائي";
    return "-";
  };

  return (
    <div className="p-6 space-y-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-attendance-title">تسجيل الحضور والانصراف</h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة سجلات الحضور اليومية</p>
        </div>
        <Button onClick={openAdd} data-testid="button-add-attendance">
          <Plus className="w-4 h-4 ml-2" />
          تسجيل حضور
        </Button>
      </div>

      <div className="flex flex-wrap gap-3 items-end">
        <div className="space-y-2">
          <Label>التاريخ</Label>
          <Input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="w-[200px]" data-testid="input-attendance-date" />
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) closeDialog(); else setDialogOpen(true); }}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingRecord ? "تعديل سجل الحضور" : "تسجيل حضور جديد"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>العامل</Label>
              <Select value={formData.employeeId} onValueChange={v => setFormData(p => ({ ...p, employeeId: v }))}>
                <SelectTrigger data-testid="select-attendance-employee"><SelectValue placeholder="اختر العامل" /></SelectTrigger>
                <SelectContent>
                  {employees?.filter(e => e.isActive).map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>{emp.name} ({emp.employeeCode})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>التاريخ</Label>
              <Input type="date" value={formData.date} onChange={e => setFormData(p => ({ ...p, date: e.target.value }))} required data-testid="input-form-date" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>وقت الحضور</Label>
                <Input type="time" value={formData.checkIn} onChange={e => setFormData(p => ({ ...p, checkIn: e.target.value }))} data-testid="input-check-in" />
              </div>
              <div className="space-y-2">
                <Label>وقت الانصراف</Label>
                <Input type="time" value={formData.checkOut} onChange={e => setFormData(p => ({ ...p, checkOut: e.target.value }))} data-testid="input-check-out" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>الحالة</Label>
              <Select value={formData.status} onValueChange={v => setFormData(p => ({ ...p, status: v }))}>
                <SelectTrigger data-testid="select-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="present">حاضر</SelectItem>
                  <SelectItem value="late">متأخر</SelectItem>
                  <SelectItem value="absent">غائب</SelectItem>
                  <SelectItem value="leave">إجازة</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Textarea value={formData.notes} onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))} data-testid="input-notes" />
            </div>
            <Button type="submit" className="w-full" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-submit-attendance">
              {(createMutation.isPending || updateMutation.isPending) ? "جاري الحفظ..." : editingRecord ? "تحديث" : "تسجيل"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : attendance && attendance.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">الرقم</TableHead>
                    <TableHead className="text-right">الاسم</TableHead>
                    <TableHead className="text-right">الشركة</TableHead>
                    <TableHead className="text-right">الورشة</TableHead>
                    <TableHead className="text-right">الفترة</TableHead>
                    <TableHead className="text-right">وقت الحضور</TableHead>
                    <TableHead className="text-right">وقت الانصراف</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                    <TableHead className="text-right">التأخير (دقيقة)</TableHead>
                    <TableHead className="text-right">ساعات العمل</TableHead>
                    <TableHead className="text-right">الخصم</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendance.map(record => {
                    const emp = employees?.find(e => e.id === record.employeeId);
                    const company = emp?.companyId ? companies?.find(c => c.id === emp.companyId) : null;
                    const workshop = emp?.workshopId ? workshops?.find(w => w.id === emp.workshopId) : null;
                    return (
                      <TableRow key={record.id} data-testid={`row-record-${record.id}`}>
                        <TableCell className="font-mono text-sm">{emp?.employeeCode}</TableCell>
                        <TableCell className="font-medium">{emp?.name || "-"}</TableCell>
                        <TableCell>{company?.name || "-"}</TableCell>
                        <TableCell>{workshop?.name || "-"}</TableCell>
                        <TableCell>{shiftLabel(emp?.shift || null)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-emerald-500" />
                            <span>{record.checkIn || "-"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-red-400" />
                            <span>{record.checkOut || "-"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={statusVariant(record.status)}>{statusLabel(record.status)}</Badge>
                        </TableCell>
                        <TableCell>{record.lateMinutes > 0 ? <span className="text-amber-600 dark:text-amber-400">{record.lateMinutes}</span> : "0"}</TableCell>
                        <TableCell>{record.totalHours || "0"}</TableCell>
                        <TableCell>{Number(record.penalty) > 0 ? <span className="text-red-600 dark:text-red-400">{record.penalty}</span> : "0"}</TableCell>
                        <TableCell>
                          <Button size="icon" variant="ghost" onClick={() => openEdit(record)} data-testid={`button-edit-record-${record.id}`}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <CalendarCheck className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm">لا توجد سجلات حضور لهذا التاريخ</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
