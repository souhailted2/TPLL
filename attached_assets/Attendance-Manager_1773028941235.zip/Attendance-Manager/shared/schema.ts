import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, time, date, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
});

export const workshops = pgTable("workshops", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
});

export const positions = pgTable("positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
});

export const workRules = pgTable("work_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  workStartTime: time("work_start_time").notNull(),
  workEndTime: time("work_end_time").notNull(),
  lateGraceMinutes: integer("late_grace_minutes").notNull().default(0),
  latePenaltyPerMinute: numeric("late_penalty_per_minute", { precision: 10, scale: 2 }).notNull().default("0"),
  earlyLeavePenaltyPerMinute: numeric("early_leave_penalty_per_minute", { precision: 10, scale: 2 }).notNull().default("0"),
  absencePenalty: numeric("absence_penalty", { precision: 10, scale: 2 }).notNull().default("0"),
  isDefault: boolean("is_default").notNull().default(false),
});

export const employees = pgTable("employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  employeeCode: text("employee_code").notNull().unique(),
  positionId: varchar("position_id").references(() => positions.id),
  workRuleId: varchar("work_rule_id").references(() => workRules.id),
  companyId: varchar("company_id").references(() => companies.id),
  workshopId: varchar("workshop_id").references(() => workshops.id),
  phone: text("phone"),
  wage: numeric("wage", { precision: 10, scale: 2 }),
  shift: text("shift"),
  contractEndDate: date("contract_end_date"),
  nonRenewalDate: date("non_renewal_date"),
  isActive: boolean("is_active").notNull().default(true),
});

export const attendanceRecords = pgTable("attendance_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  date: date("date").notNull(),
  checkIn: time("check_in"),
  checkOut: time("check_out"),
  status: text("status").notNull().default("present"),
  lateMinutes: integer("late_minutes").notNull().default(0),
  earlyLeaveMinutes: integer("early_leave_minutes").notNull().default(0),
  totalHours: numeric("total_hours", { precision: 5, scale: 2 }).default("0"),
  penalty: numeric("penalty", { precision: 10, scale: 2 }).default("0"),
  notes: text("notes"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCompanySchema = createInsertSchema(companies).pick({
  name: true,
  description: true,
});

export const insertWorkshopSchema = createInsertSchema(workshops).pick({
  name: true,
  description: true,
});

export const insertPositionSchema = createInsertSchema(positions).pick({
  name: true,
  description: true,
});

export const insertWorkRuleSchema = createInsertSchema(workRules).pick({
  name: true,
  workStartTime: true,
  workEndTime: true,
  lateGraceMinutes: true,
  latePenaltyPerMinute: true,
  earlyLeavePenaltyPerMinute: true,
  absencePenalty: true,
  isDefault: true,
});

export const insertEmployeeSchema = createInsertSchema(employees).pick({
  name: true,
  employeeCode: true,
  positionId: true,
  workRuleId: true,
  companyId: true,
  workshopId: true,
  phone: true,
  wage: true,
  shift: true,
  contractEndDate: true,
  nonRenewalDate: true,
  isActive: true,
});

export const insertAttendanceSchema = createInsertSchema(attendanceRecords).pick({
  employeeId: true,
  date: true,
  checkIn: true,
  checkOut: true,
  status: true,
  lateMinutes: true,
  earlyLeaveMinutes: true,
  totalHours: true,
  penalty: true,
  notes: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;
export type InsertWorkshop = z.infer<typeof insertWorkshopSchema>;
export type Workshop = typeof workshops.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;
export type Position = typeof positions.$inferSelect;
export type InsertWorkRule = z.infer<typeof insertWorkRuleSchema>;
export type WorkRule = typeof workRules.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;
export const deviceSettings = pgTable("device_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ipAddress: text("ip_address").notNull(),
  port: integer("port").notNull().default(4370),
  username: text("username"),
  password: text("password"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertDeviceSettingsSchema = createInsertSchema(deviceSettings).pick({
  name: true,
  ipAddress: true,
  port: true,
  username: true,
  password: true,
  isActive: true,
});

export type InsertDeviceSettings = z.infer<typeof insertDeviceSettingsSchema>;
export type DeviceSettings = typeof deviceSettings.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
