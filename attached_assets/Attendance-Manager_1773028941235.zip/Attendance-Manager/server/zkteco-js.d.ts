declare module "zkteco-js" {
  class ZKLib {
    constructor(ip: string, port: number, inport: number, timeout: number);
    createSocket(): Promise<void>;
    getInfo(): Promise<any>;
    getUsers(): Promise<{ data: any[] }>;
    getAttendances(): Promise<{ data: any[] }>;
    disconnect(): Promise<void>;
  }
  export default ZKLib;
}
