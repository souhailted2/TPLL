import ZKLib from "zkteco-js";

export interface ZKDeviceInfo {
  userCounts: number;
  logCounts: number;
  logCapacity: number;
}

export interface ZKUser {
  uid: number;
  role: number;
  name: string;
  userId: string;
  cardno: number;
  password: string;
}

export interface ZKAttendanceLog {
  deviceUserId: string;
  attStamp: string;
  recordTime: string;
}

export async function testDeviceConnection(ip: string, port: number): Promise<{ success: boolean; message: string; info?: ZKDeviceInfo }> {
  const zkInstance = new ZKLib(ip, port, 5200, 5000);
  try {
    await zkInstance.createSocket();
    const info = await zkInstance.getInfo();
    await zkInstance.disconnect();
    return {
      success: true,
      message: "تم الاتصال بالجهاز بنجاح",
      info: {
        userCounts: info?.userCounts || 0,
        logCounts: info?.logCounts || 0,
        logCapacity: info?.logCapacity || 0,
      },
    };
  } catch (error: any) {
    try { await zkInstance.disconnect(); } catch (_) {}
    return {
      success: false,
      message: `فشل الاتصال بالجهاز: ${error.message || "تأكد من أن الجهاز متصل بالشبكة وأن عنوان IP صحيح"}`,
    };
  }
}

export async function getDeviceUsers(ip: string, port: number): Promise<ZKUser[]> {
  const zkInstance = new ZKLib(ip, port, 5200, 5000);
  try {
    await zkInstance.createSocket();
    const result = await zkInstance.getUsers();
    await zkInstance.disconnect();
    return (result?.data || []).map((u: any) => ({
      uid: u.uid,
      role: u.role,
      name: u.name,
      userId: String(u.userId),
      cardno: u.cardno,
      password: u.password,
    }));
  } catch (error: any) {
    try { await zkInstance.disconnect(); } catch (_) {}
    throw new Error(`فشل جلب المستخدمين: ${error.message}`);
  }
}

export async function getDeviceAttendanceLogs(ip: string, port: number): Promise<ZKAttendanceLog[]> {
  const zkInstance = new ZKLib(ip, port, 5200, 5000);
  try {
    await zkInstance.createSocket();
    const result = await zkInstance.getAttendances();
    await zkInstance.disconnect();
    return (result?.data || []).map((log: any) => ({
      deviceUserId: String(log.deviceUserId),
      attStamp: log.attStamp,
      recordTime: log.recordTime,
    }));
  } catch (error: any) {
    try { await zkInstance.disconnect(); } catch (_) {}
    throw new Error(`فشل جلب سجلات الحضور: ${error.message}`);
  }
}
