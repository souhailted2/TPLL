import { db } from "./db";
import { positions, workRules, employees, attendanceRecords } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  const existingPositions = await db.select().from(positions);
  if (existingPositions.length > 0) return;

  const [pos1] = await db.insert(positions).values({ name: "مهندس", description: "قسم الهندسة والتصميم" }).returning();
  const [pos2] = await db.insert(positions).values({ name: "محاسب", description: "قسم المحاسبة والمالية" }).returning();
  const [pos3] = await db.insert(positions).values({ name: "إداري", description: "قسم الإدارة والتنسيق" }).returning();
  const [pos4] = await db.insert(positions).values({ name: "فني", description: "قسم الصيانة والتشغيل" }).returning();

  const [rule1] = await db.insert(workRules).values({
    name: "الدوام العادي",
    workStartTime: "08:00",
    workEndTime: "17:00",
    lateGraceMinutes: 10,
    latePenaltyPerMinute: "5.00",
    earlyLeavePenaltyPerMinute: "5.00",
    absencePenalty: "500.00",
    isDefault: true,
  }).returning();

  const [rule2] = await db.insert(workRules).values({
    name: "الدوام المسائي",
    workStartTime: "14:00",
    workEndTime: "22:00",
    lateGraceMinutes: 15,
    latePenaltyPerMinute: "3.00",
    earlyLeavePenaltyPerMinute: "3.00",
    absencePenalty: "400.00",
    isDefault: false,
  }).returning();

  const [emp1] = await db.insert(employees).values({ name: "أحمد بن علي", employeeCode: "EMP001", positionId: pos1.id, workRuleId: rule1.id, phone: "0551234567", isActive: true }).returning();
  const [emp2] = await db.insert(employees).values({ name: "محمد السعيد", employeeCode: "EMP002", positionId: pos2.id, workRuleId: rule1.id, phone: "0559876543", isActive: true }).returning();
  const [emp3] = await db.insert(employees).values({ name: "خالد الفهد", employeeCode: "EMP003", positionId: pos3.id, workRuleId: rule1.id, phone: "0553456789", isActive: true }).returning();
  const [emp4] = await db.insert(employees).values({ name: "عبدالله العمري", employeeCode: "EMP004", positionId: pos4.id, workRuleId: rule2.id, phone: "0557654321", isActive: true }).returning();
  const [emp5] = await db.insert(employees).values({ name: "سعد الدوسري", employeeCode: "EMP005", positionId: pos1.id, workRuleId: rule1.id, phone: "0552345678", isActive: true }).returning();

  const today = new Date();
  const dates: string[] = [];
  for (let i = 1; i <= 5; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    if (d.getDay() !== 0 && d.getDay() !== 6) {
      dates.push(d.toISOString().split("T")[0]);
    }
  }

  const emps = [emp1, emp2, emp3, emp4, emp5];
  for (const date of dates) {
    for (const emp of emps) {
      const isLate = Math.random() < 0.2;
      const isAbsent = Math.random() < 0.1;

      if (isAbsent) {
        await db.insert(attendanceRecords).values({
          employeeId: emp.id, date, status: "absent",
          lateMinutes: 0, earlyLeaveMinutes: 0, totalHours: "0", penalty: "500",
        });
      } else {
        const checkInH = isLate ? 8 + Math.floor(Math.random() * 2) : 7 + Math.floor(Math.random() * 1);
        const checkInM = Math.floor(Math.random() * 60);
        const checkIn = `${String(checkInH).padStart(2, "0")}:${String(checkInM).padStart(2, "0")}`;
        const checkOutH = 16 + Math.floor(Math.random() * 2);
        const checkOutM = Math.floor(Math.random() * 60);
        const checkOut = `${String(checkOutH).padStart(2, "0")}:${String(checkOutM).padStart(2, "0")}`;

        const lateMinutes = isLate ? (checkInH * 60 + checkInM) - (8 * 60 + 10) : 0;
        const totalHours = Math.round(((checkOutH * 60 + checkOutM) - (checkInH * 60 + checkInM)) / 60 * 100) / 100;
        const penalty = lateMinutes > 0 ? lateMinutes * 5 : 0;

        await db.insert(attendanceRecords).values({
          employeeId: emp.id, date, checkIn, checkOut,
          status: isLate ? "late" : "present",
          lateMinutes: Math.max(0, lateMinutes),
          earlyLeaveMinutes: 0,
          totalHours: String(totalHours),
          penalty: String(penalty),
        });
      }
    }
  }

  console.log("Seed data inserted successfully");
}
