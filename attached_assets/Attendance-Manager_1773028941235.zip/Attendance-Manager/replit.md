# Attendance Management System - نظام إدارة الحضور والانصراف

## Overview
A comprehensive worker attendance management system built with React + Express + PostgreSQL. Supports worker management with company affiliation, workshop assignment, wages, shifts (morning/evening), contract tracking, daily attendance recording (check-in/check-out), monthly reports with totals, work rules with penalties, ZK device sync, and CSV import.

## Architecture
- **Frontend**: React + TypeScript + Tailwind CSS + Shadcn UI, RTL layout (Arabic)
- **Backend**: Express.js + Drizzle ORM
- **Database**: PostgreSQL (Neon-backed)
- **Routing**: Wouter for client-side routing

## Project Structure
- `shared/schema.ts` - Database schema (companies, workshops, positions, workRules, employees, attendanceRecords, deviceSettings)
- `server/routes.ts` - API endpoints
- `server/storage.ts` - Database storage layer (IStorage interface + DatabaseStorage)
- `server/db.ts` - Database connection
- `server/seed.ts` - Seed data
- `server/zk-service.ts` - ZKTeco device communication
- `client/src/pages/` - Dashboard, Employees, Attendance, Reports, Companies, Workshops, Positions, WorkRules, DeviceSettings, ImportData
- `client/src/components/` - AppSidebar, ThemeToggle

## Key Features
- Worker management with company, workshop, wage, shift, contract dates
- Companies management (شركات)
- Workshops management (ورش)
- Daily attendance recording (check-in/check-out)
- Automatic late/early leave penalty calculation
- Monthly attendance summary reports with totals row
- Work rules configuration (start/end times, grace periods, penalties)
- Dashboard with contract expiry alerts
- ZK biometric device sync (local network)
- CSV import for attendance and workers
- RTL Arabic interface with dark mode support

## API Endpoints
- GET/POST /api/companies, PATCH/DELETE /api/companies/:id
- GET/POST /api/workshops, PATCH/DELETE /api/workshops/:id
- GET/POST /api/positions, PATCH/DELETE /api/positions/:id
- GET/POST /api/work-rules, PATCH/DELETE /api/work-rules/:id
- GET/POST /api/employees, PATCH /api/employees/:id
- GET /api/attendance?date=YYYY-MM-DD, POST /api/attendance, PATCH /api/attendance/:id
- GET /api/reports/monthly?month=MM&year=YYYY (includes companyName, workshopName, shift, wage)
- GET/POST /api/device-settings, PATCH/DELETE /api/device-settings/:id
- POST /api/device-settings/:id/test, /sync, /users
- POST /api/import/attendance (CSV file upload)

## Database Tables
- **companies** - id, name, description
- **workshops** - id, name, description
- **positions** - id, name, description
- **work_rules** - id, name, workStartTime, workEndTime, lateGraceMinutes, penalties, isDefault
- **employees** - id, name, employeeCode, positionId, workRuleId, companyId, workshopId, phone, wage, shift, contractEndDate, nonRenewalDate, isActive
- **attendance_records** - id, employeeId, date, checkIn, checkOut, status, lateMinutes, earlyLeaveMinutes, totalHours, penalty, notes
- **device_settings** - id, name, ipAddress, port, isActive

## Running
- `npm run dev` starts Express backend + Vite frontend on port 5000
- `npm run db:push` syncs schema to database
